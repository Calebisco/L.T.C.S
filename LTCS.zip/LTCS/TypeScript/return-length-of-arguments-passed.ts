// Time:  O(1)
// Space: O(1)

function argumentsLength(...args: any[]): number {
    return args.length;
};
